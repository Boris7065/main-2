# Family SOS 🚨

One press alerts everyone in your family. **No accounts. No login.**

```
Open app → Create/Join family → See members → HOLD emergency button 3s
        → every other member gets a Web Push + loud siren + vibration for 30s
        → member taps STOP ALARM (or CALL / VIEW LOCATION / I'M RESPONDING)
```

This repository contains **two ways to run the exact same app**:

| Folder | What it is | Use it when |
| --- | --- | --- |
| `src/` (root) | The hosted version (React app + API routes + PostgreSQL) — this is what the preview runs. | You want the sandbox/preview build. |
| `standalone/` | A **self-contained React + Vite 4 project** for **macOS 10.15 Catalina (Intel x86_64)** — no Next.js, no Turbopack, no macOS 11+ dependencies. | You want to run it locally with `npm install && npm run dev`. |

➡️ For local Catalina use, read **[`standalone/README.md`](standalone/README.md)**.

## Quick start (standalone, Catalina friendly)

```bash
cd standalone
cp .env.example .env          # set DATABASE_URL
psql "$DATABASE_URL" -f schema.sql
npm install
npm run dev                   # app on :5173, API on :8787
```

Open the URL on your phone (same Wi-Fi) with a second family member on your laptop to see the
real-time alert flow.

## Feature checklist

* **Start screen** — CREATE A FAMILY / JOIN A FAMILY. No signup.
* **Create** — family name + your name → unique invite code (`JHN-4829`), **COPY CODE** and **SHARE INVITE**, live `n / 100 Members` counter.
* **Join** — your name + invite code (accepts a code, a full link, or pasted invite text).
* **100 member hard limit** — enforced inside a row-locked transaction; member 101 gets
  “This family is full. Maximum 100 members allowed.”
* **Home** — family name, member count, every member listed, and one huge 🚨 EMERGENCY button
  that needs **3 seconds of continuous pressing** (a progress ring fills; releasing early cancels).
* **Emergency** — creates a real database record, sends **Web Push** to every other member,
  plays a **loud siren**, **vibrates the phone**, and opens the emergency screen.
  The alarm runs **30 seconds** or until **STOP ALARM** is pressed.
* **Emergency screen** — name, family name, alert time, location + map, and
  **CALL** / **VIEW LOCATION** / **STOP ALARM** / **I'M RESPONDING**.
* **Status** — the person who triggered it switches **ACTIVE ⇄ SAFE**; SAFE notifies everyone:
  “[Name] has marked themselves SAFE.”
* **Family screen** — family name, member count, all members, invite code, Copy / Share.
* **History** — every alert with person, date, time and status (Active / Resolved).
* **Location** — requested on trigger; granted → coordinates + map, denied/timeout → the alert is
  still sent. Location can never block an emergency.
* **Design** — mobile-first, dark, high contrast, red emergency accents, bottom tabs
  `HOME | FAMILY | HISTORY`, no unnecessary animation or menus.

## How the "real" alerting works

1. **Trigger** — pointer hold for 3000 ms → `POST /api/emergencies` (retried up to 3×, best-effort location).
2. **Fan-out** — the server inserts the emergency and immediately sends a **Web Push** message
   (VAPID, `urgency: high`, vibrate pattern, `requireInteraction`) to every other member's
   stored subscription. The service worker (`public/sw.js`) displays it even when the app is
   closed; tapping it opens the app straight on that emergency.
3. **In-app** — every client holds a live **Server-Sent Events** stream (`/api/stream`) that pushes
   the family snapshot whenever anything changes, and automatically falls back to 2-second
   polling if a proxy blocks SSE.
4. **Alarm** — Web Audio siren + Vibration API + screen wake lock, auto-stopped after 30 s
   (one tap unlocks audio on iOS/Android; the app shows a one-time
   “Tap to turn on alarm sound & notifications” banner).
5. **Stop** — **STOP ALARM** halts audio and vibration instantly.

> Browsers cannot play sound from a push while the page is fully closed — that is a platform
> rule, not a limitation of this app. The push notification (with vibration) still arrives, and
> the siren starts the moment the alert is opened. Install to the home screen for best results.

## Screens

```
START            CREATE → family name, your name → invite code + copy/share
                 JOIN   → your name, invite code
HOME             family name · members n/100 · member list · 🚨 EMERGENCY (hold 3s)
EMERGENCY        🚨 FAMILY EMERGENCY · name · family · time · map · CALL / VIEW LOCATION / STOP ALARM / I'M RESPONDING
MY ALERT         status ACTIVE ⇄ SAFE · who is responding
FAMILY           family name · count · invite code · copy/share · all members
HISTORY          person · date · time · status
```

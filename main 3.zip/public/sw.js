/* Family SOS service worker.
   - Real Web Push: shows a high-priority notification even when the app is
     closed or in the background.
   - Tapping the notification opens the app straight on the emergency. */

self.addEventListener("install", () => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  event.waitUntil(self.clients.claim());
});

self.addEventListener("push", (event) => {
  let data = {};
  try {
    data = event.data ? event.data.json() : {};
  } catch (error) {
    data = {};
  }

  const name = data.memberName || "A family member";
  const family = data.familyName || "your family";
  const isSafe = data.type === "safe";

  const title = isSafe ? name + " is SAFE" : "FAMILY EMERGENCY";
  const body = isSafe
    ? name + " has marked themselves SAFE."
    : name + " has triggered an emergency alert. Please check on them immediately. (" + family + ")";

  const options = {
    body: body,
    tag: data.emergencyId || "family-sos",
    renotify: true,
    requireInteraction: !isSafe,
    silent: false,
    vibrate: isSafe ? [120] : [500, 200, 500, 200, 1000, 400],
    badge: undefined,
    data: {
      url:
        (self.registration.scope || "/") +
        (data.emergencyId ? "?emergency=" + encodeURIComponent(data.emergencyId) : ""),
    },
  };

  event.waitUntil(self.registration.showNotification(title, options));
});

self.addEventListener("notificationclick", (event) => {
  event.notification.close();
  const url = (event.notification.data && event.notification.data.url) || self.registration.scope || "/";

  event.waitUntil(
    self.clients.matchAll({ type: "window", includeUncontrolled: true }).then((clientList) => {
      for (let i = 0; i < clientList.length; i += 1) {
        const client = clientList[i];
        if ("focus" in client) {
          if ("navigate" in client) {
            try {
              client.navigate(url);
            } catch (error) {
              /* ignore */
            }
          }
          return client.focus();
        }
      }
      if (self.clients.openWindow) {
        return self.clients.openWindow(url);
      }
      return undefined;
    }),
  );
});

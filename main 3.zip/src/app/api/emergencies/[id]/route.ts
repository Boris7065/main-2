import { addResponse, setEmergencyStatus } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

export async function PATCH(request: Request, context: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await context.params;
    const body = await request.json();
    const action = body?.action;

    if (action === "status") {
      const result = await setEmergencyStatus({
        emergencyId: id,
        memberId: body?.memberId,
        status: body?.status,
      });
      if (result.error) {
        return Response.json({ error: result.error }, { status: result.status ?? 400 });
      }
      return Response.json({ ok: true, status: result.status });
    }

    if (action === "respond") {
      await addResponse({
        emergencyId: id,
        memberId: body?.memberId,
        memberName: body?.memberName,
        response: body?.response,
      });
      return Response.json({ ok: true });
    }

    return Response.json({ error: "Unknown action" }, { status: 400 });
  } catch (error) {
    console.error("emergency update failed", error);
    return Response.json({ error: "Could not update the emergency." }, { status: 500 });
  }
}

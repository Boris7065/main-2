import { createEmergency } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const result = await createEmergency({
      familyId: body?.familyId,
      memberId: body?.memberId,
      lat: body?.lat,
      lng: body?.lng,
      accuracy: body?.accuracy,
    });
    if (result.error) {
      return Response.json({ error: result.error }, { status: result.status ?? 400 });
    }
    return Response.json(result, { status: 201 });
  } catch (error) {
    console.error("emergency failed", error);
    return Response.json({ error: "Could not send the emergency." }, { status: 500 });
  }
}

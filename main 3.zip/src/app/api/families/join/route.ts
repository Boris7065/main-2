import { joinFamily } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const result = await joinFamily({
      inviteCode: body?.inviteCode,
      memberName: body?.memberName,
    });
    if (result.error) {
      return Response.json({ error: result.error }, { status: result.status ?? 400 });
    }
    return Response.json(result, { status: 201 });
  } catch (error) {
    console.error("join family failed", error);
    return Response.json({ error: "Could not join the family. Please try again." }, { status: 500 });
  }
}

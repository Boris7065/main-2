import { createFamily } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

export async function POST(request: Request) {
  try {
    const body = await request.json();
    const result = await createFamily({
      familyName: body?.familyName,
      memberName: body?.memberName,
    });
    if (result.error) {
      return Response.json({ error: result.error }, { status: result.status ?? 400 });
    }
    return Response.json(result, { status: 201 });
  } catch (error) {
    console.error("create family failed", error);
    return Response.json({ error: "Could not create the family. Please try again." }, { status: 500 });
  }
}

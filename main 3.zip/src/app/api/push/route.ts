import { getVapidPublicKey, savePushSubscription } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

export async function GET() {
  try {
    const publicKey = await getVapidPublicKey();
    return Response.json({ publicKey: publicKey ?? null });
  } catch (error) {
    console.error("vapid key failed", error);
    return Response.json({ publicKey: null });
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    await savePushSubscription(body?.memberId, body?.subscription);
    return Response.json({ ok: true });
  } catch (error) {
    console.error("push subscribe failed", error);
    return Response.json({ ok: false }, { status: 200 });
  }
}

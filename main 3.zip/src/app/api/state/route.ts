import { getSnapshot, touchMember } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  try {
    const url = new URL(request.url);
    const familyId = url.searchParams.get("familyId") ?? "";
    const memberId = url.searchParams.get("memberId") ?? "";
    if (!familyId) {
      return Response.json({ error: "familyId is required" }, { status: 400 });
    }
    const snapshot = await getSnapshot(familyId);
    if (!snapshot) {
      return Response.json({ error: "Family not found" }, { status: 404 });
    }
    if (memberId) void touchMember(memberId);
    return Response.json(snapshot, {
      headers: { "Cache-Control": "no-store" },
    });
  } catch (error) {
    console.error("snapshot failed", error);
    return Response.json({ error: "Could not load family state." }, { status: 500 });
  }
}

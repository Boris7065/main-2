import { getFamilyVersion, getSnapshot } from "@/server/core.mjs";

export const dynamic = "force-dynamic";

/**
 * Server-Sent Events stream of the family snapshot.
 * Every connected family member receives a new snapshot as soon as anything
 * changes (new member, new emergency, "I'm responding", "SAFE", ...).
 * The browser client falls back to plain polling automatically if SSE is
 * blocked by a proxy.
 */
export async function GET(request: Request) {
  const url = new URL(request.url);
  const familyId = url.searchParams.get("familyId") ?? "";
  const memberId = url.searchParams.get("memberId") ?? "";

  if (!familyId) {
    return new Response("familyId is required", { status: 400 });
  }

  const encoder = new TextEncoder();

  const stream = new ReadableStream<Uint8Array>({
    async start(controller) {
      let closed = false;
      let lastVersion = "";

      const close = () => {
        if (closed) return;
        closed = true;
        try {
          controller.close();
        } catch {
          /* already closed */
        }
      };

      const write = (chunk: string) => {
        if (closed) return;
        try {
          controller.enqueue(encoder.encode(chunk));
        } catch {
          closed = true;
        }
      };

      const send = (event: string, data: unknown) => {
        write(`event: ${event}\ndata: ${JSON.stringify(data)}\n\n`);
      };

      request.signal.addEventListener("abort", close);

      write("retry: 2000\n\n");

      const pushSnapshot = async () => {
        const snapshot = await getSnapshot(familyId);
        if (!snapshot) {
          send("gone", { ok: false });
          close();
          return;
        }
        send("snapshot", snapshot);
      };

      try {
        const initial = await getSnapshot(familyId);
        lastVersion = initial ? await getFamilyVersion(familyId) : "0";
        await pushSnapshot();
      } catch (error) {
        console.error("stream initial snapshot failed", error);
      }

      let ticks = 0;
      while (!closed) {
        await new Promise((resolve) => setTimeout(resolve, 1500));
        if (closed) break;
        ticks += 1;
        try {
          const version = await getFamilyVersion(familyId);
          if (version !== lastVersion) {
            lastVersion = version;
            await pushSnapshot();
            continue;
          }
          if (ticks % 10 === 0) {
            write(`: ping ${Date.now()}\n\n`);
          }
        } catch (error) {
          console.error("stream tick failed", error);
        }
      }
    },
  });

  return new Response(stream, {
    headers: {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
      "X-Accel-Buffering": "no",
    },
  });
}

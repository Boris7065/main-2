"use client";

import App from "@/familysos/App";

export default function FamilySos() {
  return <App />;
}

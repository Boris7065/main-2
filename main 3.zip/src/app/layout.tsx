import type { Metadata, Viewport } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import "@/familysos/app.css";

export const metadata: Metadata = {
  title: "Family SOS",
  description: "One press alerts everyone in your family.",
  manifest: "/manifest.webmanifest",
  appleWebApp: { capable: true, title: "Family SOS", statusBarStyle: "black-translucent" },
};

export const viewport: Viewport = {
  width: "device-width",
  initialScale: 1,
  maximumScale: 1,
  userScalable: false,
  themeColor: "#e11d2e",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>{children}</body>
    </html>
  );
}

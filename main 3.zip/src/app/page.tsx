import FamilySos from "./family-sos";

export const dynamic = "force-dynamic";

export default function HomePage() {
  return <FamilySos />;
}

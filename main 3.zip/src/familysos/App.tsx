import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import {
  clearIdentity,
  createEmergency,
  createFamily,
  fetchSnapshot,
  getVapidPublicKey,
  getLocation,
  joinFamily,
  loadIdentity,
  markEmergencyStatus,
  respondToEmergency,
  saveIdentity,
  savePushSubscription,
  urlBase64ToUint8Array,
} from "./api";
import { ALARM_DURATION_MS, alarm } from "./alarm";
import {
  CreateScreen,
  CreatedScreen,
  FamilyScreen,
  HistoryScreen,
  JoinScreen,
  Logo,
  StartScreen,
  MembersStrip,
} from "./screens";
import { SosButton } from "./SosButton";
import { EmergencyOverlay } from "./EmergencyOverlay";
import type { Identity, SosSnapshot } from "./types";

type Phase = "start" | "create" | "join" | "created" | "app";
type Tab = "home" | "family" | "history";

const HOLD_HINT_DELAY_MS = 600;

export default function App() {
  const [identity, setIdentity] = useState<Identity | null>(() => loadIdentity());
  const [phase, setPhase] = useState<Phase>(() => (loadIdentity() ? "app" : "start"));
  const [snapshot, setSnapshot] = useState<SosSnapshot | null>(null);
  const [created, setCreated] = useState<{ familyName: string; inviteCode: string } | null>(null);
  const [busy, setBusy] = useState(false);
  const [sending, setSending] = useState(false);
  const [error, setError] = useState("");
  const [hint, setHint] = useState("");
  const [joinCode, setJoinCode] = useState("");
  const [tab, setTab] = useState<Tab>("home");
  const [now, setNow] = useState(() => Date.now());
  const [alarmRunning, setAlarmRunning] = useState(false);
  const [alertsReady, setAlertsReady] = useState(false);
  const [live, setLive] = useState(false);
  const [safeNotice, setSafeNotice] = useState("");
  const safeTimerRef = useRef<ReturnType<typeof setTimeout> | null>(null);
  const knownActiveRef = useRef<Map<string, string>>(new Map());

  const seenRef = useRef<Set<string>>(new Set());
  const stoppedRef = useRef<Set<string>>(new Set());
  const firstSnapshotRef = useRef(true);

  /* -------------------- deep links (?join=CODE) -------------------- */
  useEffect(() => {
    try {
      const params = new URLSearchParams(window.location.search);
      const code = params.get("join");
      if (code) {
        setJoinCode(code);
        if (!loadIdentity()) setPhase("join");
      }
      if (params.toString()) {
        window.history.replaceState({}, "", window.location.pathname);
      }
    } catch {
      /* ignore */
    }
  }, []);

  /* -------------------- realtime family stream -------------------- */
  useEffect(() => {
    if (!identity) return;
    let cancelled = false;
    let source: EventSource | null = null;
    let pollTimer: ReturnType<typeof setInterval> | null = null;

    const apply = (next: SosSnapshot) => {
      if (!cancelled) setSnapshot(next);
    };

    const startPolling = () => {
      if (pollTimer || cancelled) return;
      pollTimer = setInterval(async () => {
        if (!identity) return;
        const next = await fetchSnapshot(identity.familyId, identity.memberId);
        if (next) apply(next);
      }, 2000);
    };

    try {
      source = new EventSource(
        `/api/stream?familyId=${encodeURIComponent(identity.familyId)}&memberId=${encodeURIComponent(
          identity.memberId,
        )}`,
      );
      source.addEventListener("snapshot", (event) => {
        setLive(true);
        try {
          apply(JSON.parse((event as MessageEvent).data) as SosSnapshot);
        } catch {
          /* ignore malformed frame */
        }
      });
      source.addEventListener("gone", () => {
        clearIdentity();
        setIdentity(null);
        setPhase("start");
      });
      source.onerror = () => {
        setLive(false);
        try {
          source?.close();
        } catch {
          /* ignore */
        }
        source = null;
        startPolling();
      };
    } catch {
      startPolling();
    }

    return () => {
      cancelled = true;
      try {
        source?.close();
      } catch {
        /* ignore */
      }
      if (pollTimer) clearInterval(pollTimer);
    };
  }, [identity]);

  /* -------------------- clock for elapsed labels -------------------- */
  useEffect(() => {
    const timer = setInterval(() => setNow(Date.now()), 1000);
    return () => clearInterval(timer);
  }, []);

  /* -------------------- service worker + push -------------------- */
  useEffect(() => {
    if (typeof navigator === "undefined" || !("serviceWorker" in navigator)) return;
    navigator.serviceWorker.register("/sw.js").catch(() => undefined);
  }, []);

  const enableAlerts = useCallback(async () => {
    await alarm.unlock();
    try {
      if ("Notification" in window && Notification.permission !== "granted") {
        await Notification.requestPermission();
      }
      if ("serviceWorker" in navigator && "PushManager" in window && identity) {
        const registration = await navigator.serviceWorker.register("/sw.js");
        const key = await getVapidPublicKey();
        const existing = await registration.pushManager.getSubscription();
        const subscription =
          existing ??
          (key
            ? await registration.pushManager.subscribe({
                userVisibleOnly: true,
                applicationServerKey: urlBase64ToUint8Array(key),
              })
            : null);
        if (subscription) await savePushSubscription(identity.memberId, subscription);
      }
    } catch {
      /* push is a bonus layer - in-app alarms still work */
    }
    const granted = "Notification" in window ? Notification.permission === "granted" : false;
    setAlertsReady(granted && alarm.isReady);
  }, [identity]);

  useEffect(() => {
    if (!identity) return;
    let cancelled = false;
    (async () => {
      await alarm.unlock();
      const granted = "Notification" in window ? Notification.permission === "granted" : false;
      if (!cancelled) setAlertsReady(granted && alarm.isReady);
    })();
    return () => {
      cancelled = true;
    };
  }, [identity]);

  /* -------------------- incoming alarm handling -------------------- */
  const incoming = useMemo(() => {
    if (!snapshot || !identity) return null;
    return snapshot.active.find((item) => item.memberId !== identity.memberId) ?? null;
  }, [snapshot, identity]);

  const mine = useMemo(() => {
    if (!snapshot || !identity) return null;
    return snapshot.active.find((item) => item.memberId === identity.memberId) ?? null;
  }, [snapshot, identity]);

  useEffect(() => {
    if (!incoming) {
      if (alarm.isPlaying) alarm.stop();
      setAlarmRunning(false);
      firstSnapshotRef.current = false;
      document.title = "Family SOS";
      return;
    }
    const fresh = !seenRef.current.has(incoming.id);
    seenRef.current.add(incoming.id);
    document.title = `🚨 EMERGENCY — ${incoming.memberName}`;

    if (fresh && !stoppedRef.current.has(incoming.id)) {
      setAlarmRunning(true);
      void alarm.start(ALARM_DURATION_MS);
      if (typeof document !== "undefined" && document.hidden && "Notification" in window) {
        try {
          if (Notification.permission === "granted") {
            new Notification("🚨 FAMILY EMERGENCY", {
              body: `${incoming.memberName} has triggered an emergency alert. Tap to open.`,
              tag: incoming.id,
            });
          }
        } catch {
          /* ignore */
        }
      }
    }
    firstSnapshotRef.current = false;
  }, [incoming]);

  useEffect(() => {
    if (alarmRunning && !incoming) alarm.stop();
  }, [alarmRunning, incoming]);

  /* -------------------- "marked themselves SAFE" notice -------------- */
  useEffect(() => {
    if (!snapshot) return;
    const known = knownActiveRef.current;
    for (const item of snapshot.active) known.set(item.id, item.memberName);
    for (const [id, name] of Array.from(known.entries())) {
      if (snapshot.active.some((item) => item.id === id)) continue;
      known.delete(id);
      const record = snapshot.history.find((item) => item.id === id);
      if (!record || record.status !== "safe") continue;
      setSafeNotice(`${name} has marked themselves SAFE.`);
      if (safeTimerRef.current) clearTimeout(safeTimerRef.current);
      safeTimerRef.current = setTimeout(() => setSafeNotice(""), 12000);
    }
  }, [snapshot]);

  /* -------------------- actions -------------------- */
  const handleCreate = useCallback(
    async (familyName: string, memberName: string) => {
      setBusy(true);
      setError("");
      try {
        const result = await createFamily(familyName, memberName);
        saveIdentity({
          memberId: result.memberId,
          familyId: result.familyId,
          name: memberName.trim(),
          familyName: familyName.trim(),
          inviteCode: result.inviteCode,
        });
        setCreated({ familyName: familyName.trim(), inviteCode: result.inviteCode });
        setIdentity({
          memberId: result.memberId,
          familyId: result.familyId,
          name: memberName.trim(),
          familyName: familyName.trim(),
          inviteCode: result.inviteCode,
        });
        setPhase("created");
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : "Could not create the family.");
      } finally {
        setBusy(false);
      }
    },
    [],
  );

  const handleJoin = useCallback(
    async (code: string, memberName: string) => {
      setBusy(true);
      setError("");
      try {
        const result = await joinFamily(code, memberName);
        saveIdentity({
          memberId: result.memberId,
          familyId: result.familyId,
          name: memberName.trim(),
          inviteCode: result.inviteCode,
        });
        setIdentity({
          memberId: result.memberId,
          familyId: result.familyId,
          name: memberName.trim(),
          inviteCode: result.inviteCode,
        });
        setPhase("app");
        setTab("home");
      } catch (caught) {
        setError(caught instanceof Error ? caught.message : "Could not join the family.");
      } finally {
        setBusy(false);
      }
    },
    [],
  );

  const triggerEmergency = useCallback(async () => {
    if (!identity || sending) return;
    setSending(true);
    setError("");
    try {
      // Location is best-effort: never let it delay or block the alert.
      let coords: { lat: number; lng: number; accuracy: number | null } | null = null;
      try {
        const permission =
          typeof navigator !== "undefined" && navigator.permissions
            ? await navigator.permissions.query({ name: "geolocation" as PermissionName })
            : null;
        if (!permission || permission.state === "granted") {
          coords = await getLocation(6000);
        } else {
          void getLocation(2000);
        }
      } catch {
        coords = null;
      }

      let delivered = false;
      let lastError: unknown = null;
      for (let attempt = 0; attempt < 3 && !delivered; attempt += 1) {
        try {
          await createEmergency(identity.familyId, identity.memberId, coords);
          delivered = true;
        } catch (caught) {
          lastError = caught;
          await new Promise((resolve) => setTimeout(resolve, 700));
        }
      }
      if (!delivered) {
        throw lastError instanceof Error ? lastError : new Error("Emergency could not be sent.");
      }
      const next = await fetchSnapshot(identity.familyId, identity.memberId);
      if (next) setSnapshot(next);
    } catch (caught) {
      setError(caught instanceof Error ? caught.message : "Emergency could not be sent.");
    } finally {
      setSending(false);
    }
  }, [identity, sending]);

  const stopAlarm = useCallback(() => {
    alarm.stop();
    setAlarmRunning(false);
    if (incoming) stoppedRef.current.add(incoming.id);
  }, [incoming]);

  const respond = useCallback(async () => {
    if (!identity || !incoming) return;
    try {
      await respondToEmergency(
        incoming.id,
        identity.memberId,
        identity.name || "Family member",
        "responding",
      );
      const next = await fetchSnapshot(identity.familyId, identity.memberId);
      if (next) setSnapshot(next);
    } catch {
      setError("Could not send your response.");
    }
  }, [identity, incoming]);

  const setStatus = useCallback(
    async (status: "active" | "safe") => {
      if (!identity || !mine) return;
      try {
        await markEmergencyStatus(mine.id, identity.memberId, status);
        const next = await fetchSnapshot(identity.familyId, identity.memberId);
        if (next) setSnapshot(next);
      } catch {
        setError("Could not update your status.");
      }
    },
    [identity, mine],
  );

  const leaveFamily = useCallback(() => {
    alarm.stop();
    clearIdentity();
    setIdentity(null);
    setSnapshot(null);
    setPhase("start");
  }, []);

  /* -------------------- render -------------------- */
  if (phase === "start") {
    return (
      <div className="app">
        <StartScreen
          onCreate={() => {
            setError("");
            setPhase("create");
          }}
          onJoin={() => {
            setError("");
            setPhase("join");
          }}
        />
      </div>
    );
  }

  if (phase === "create") {
    return (
      <div className="app">
        <CreateScreen
          busy={busy}
          error={error}
          onBack={() => setPhase("start")}
          onSubmit={handleCreate}
        />
      </div>
    );
  }

  if (phase === "join") {
    return (
      <div className="app">
        <JoinScreen
          busy={busy}
          error={error}
          initialCode={joinCode}
          onBack={() => setPhase("start")}
          onSubmit={handleJoin}
        />
      </div>
    );
  }

  if (phase === "created" && created) {
    return (
      <div className="app">
        <CreatedScreen
          familyName={created.familyName}
          inviteCode={created.inviteCode}
          onContinue={() => setPhase("app")}
        />
      </div>
    );
  }

  const familyName = snapshot?.family.name ?? identity?.familyName ?? "Your Family";
  const showOverlay = Boolean(incoming || mine);

  return (
    <div className="app">
      {safeNotice ? <div className="safe-banner">✅ {safeNotice}</div> : null}
      {showOverlay && incoming ? (
        <EmergencyOverlay
          emergency={incoming}
          familyName={familyName}
          memberCount={snapshot?.family.memberCount ?? 0}
          isMine={false}
          myMemberId={identity?.memberId ?? ""}
          alarmRunning={alarmRunning}
          now={now}
          busy={false}
          onStopAlarm={stopAlarm}
          onRespond={respond}
          onSetStatus={setStatus}
        />
      ) : null}

      {showOverlay && mine ? (
        <EmergencyOverlay
          emergency={mine}
          familyName={familyName}
          memberCount={snapshot?.family.memberCount ?? 0}
          isMine
          myMemberId={identity?.memberId ?? ""}
          alarmRunning={alarmRunning}
          now={now}
          busy={sending}
          onStopAlarm={stopAlarm}
          onRespond={respond}
          onSetStatus={setStatus}
        />
      ) : null}

      {!showOverlay ? (
        <>
          <header className="header">
            <Logo small />
            <div className="header-meta">
              <span className="family-name">{familyName}</span>
              <span className="member-count">
                Members: {snapshot?.family.memberCount ?? 1} / {snapshot?.family.maxMembers ?? 100}
              </span>
              <span className={live ? "live on" : "live"}>
                {live ? "● live" : "○ connecting"}
              </span>
            </div>
          </header>

          {identity && !alertsReady ? (
            <button type="button" className="alert-setup" onClick={enableAlerts}>
              🔔 Tap to turn on alarm sound &amp; notifications
            </button>
          ) : null}

          <main className="main">
            {tab === "home" ? (
              <>
                {error ? <p className="error">{error}</p> : null}
                <SosButton
                  disabled={sending}
                  onTrigger={triggerEmergency}
                  onEarlyRelease={() => {
                    setHint("Keep holding for 3 full seconds.");
                    window.setTimeout(() => setHint(""), HOLD_HINT_DELAY_MS + 1800);
                  }}
                />
                {sending ? <p className="sending">SENDING ALERT...</p> : null}
                {hint ? <p className="hint">{hint}</p> : null}
                {snapshot ? <MembersStrip snapshot={snapshot} /> : <p className="loading">Loading family…</p>}
              </>
            ) : null}

            {tab === "family" && snapshot ? (
              <FamilyScreen snapshot={snapshot} myMemberId={identity?.memberId ?? ""} onLeave={leaveFamily} />
            ) : null}

            {tab === "history" && snapshot ? <HistoryScreen history={snapshot.history} /> : null}

            {!snapshot ? (
              <div className="screen center">
                <Logo />
                <p className="loading">Connecting to your family…</p>
              </div>
            ) : null}
          </main>

          <nav className="tabbar">
            <button
              type="button"
              className={tab === "home" ? "tab active" : "tab"}
              onClick={() => setTab("home")}
            >
              HOME
            </button>
            <button
              type="button"
              className={tab === "family" ? "tab active" : "tab"}
              onClick={() => setTab("family")}
            >
              FAMILY
            </button>
            <button
              type="button"
              className={tab === "history" ? "tab active" : "tab"}
              onClick={() => setTab("history")}
            >
              HISTORY
            </button>
          </nav>
        </>
      ) : null}
    </div>
  );
}

import type { SosEmergency } from "./types";
import { formatTime, elapsedLabel } from "./util";
import { MapCard } from "./screens";

export function EmergencyOverlay({
  emergency,
  familyName,
  memberCount,
  isMine,
  myMemberId,
  alarmRunning,
  now,
  onStopAlarm,
  onRespond,
  onSetStatus,
  busy,
}: {
  emergency: SosEmergency;
  familyName: string;
  memberCount: number;
  isMine: boolean;
  myMemberId: string;
  alarmRunning: boolean;
  now: number;
  onStopAlarm: () => void;
  onRespond: () => void;
  onSetStatus: (status: "active" | "safe") => void;
  busy: boolean;
}) {
  const responders = emergency.responses.filter((r) => r.response === "responding");
  const alreadyResponding = responders.some((r) => r.memberId === myMemberId);

  if (isMine) {
    const safe = emergency.status === "safe";
    return (
      <div className="overlay">
        <div className="overlay-head">
          <p className="overlay-title">🚨 EMERGENCY</p>
          <p className="overlay-sub">{safe ? "You are marked SAFE" : "Your alert is active"}</p>
        </div>

        <div className="overlay-body">
          <h1 className="alert-name">{emergency.memberName}</h1>
          <p className="alert-line">
            <strong>{familyName}</strong> · {memberCount} members alerted
          </p>
          <p className="alert-line">Alert sent at {formatTime(emergency.createdAt)}</p>

          {safe ? (
            <div className="safe-box">
              <p>
                <strong>You marked yourself SAFE.</strong>
              </p>
              <p>Your family has been notified that you are safe.</p>
              <button
                type="button"
                className="btn btn-danger-ghost"
                disabled={busy}
                onClick={() => onSetStatus("active")}
              >
                MARK ACTIVE AGAIN
              </button>
            </div>
          ) : (
            <>
              <div className="responders">
                <p className="card-label">RESPONDING</p>
                {responders.length === 0 ? (
                  <p className="card-sub">Nobody has responded yet.</p>
                ) : (
                  <ul>
                    {responders.map((r) => (
                      <li key={r.memberId}>{r.name}</li>
                    ))}
                  </ul>
                )}
              </div>
              <button
                type="button"
                className="btn btn-safe btn-xl"
                disabled={busy}
                onClick={() => onSetStatus("safe")}
              >
                I&apos;M SAFE
              </button>
              <p className="fineprint">
                Pressing I&apos;M SAFE tells everyone: &ldquo;{emergency.memberName} has marked
                themselves SAFE.&rdquo;
              </p>
            </>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="overlay danger">
      <div className="overlay-head">
        <p className="overlay-title">🚨 FAMILY EMERGENCY</p>
        <p className="overlay-sub">
          {emergency.memberName} has triggered an emergency alert.
          <br />
          Please check on them immediately.
        </p>
      </div>

      <div className="overlay-body">
        <h1 className="alert-name big">{emergency.memberName} needs help.</h1>
        <div className="alert-meta">
          <div>
            <p className="card-label">NAME</p>
            <p className="alert-line strong">{emergency.memberName}</p>
          </div>
          <div>
            <p className="card-label">FAMILY</p>
            <p className="alert-line strong">{familyName}</p>
          </div>
          <div>
            <p className="card-label">TIME</p>
            <p className="alert-line strong">
              {formatTime(emergency.createdAt)}{" "}
              <span className="muted">({elapsedLabel(emergency.createdAt, now)})</span>
            </p>
          </div>
        </div>

        <MapCard emergency={emergency} />

        {responders.length > 0 ? (
          <p className="ok-note">Responding: {responders.map((r) => r.name).join(", ")}</p>
        ) : null}

        <div className="row">
          <a className="btn btn-safe" href="tel:911">
            CALL
          </a>
          {typeof emergency.lat === "number" && typeof emergency.lng === "number" ? (
            <a
              className="btn btn-ghost"
              href={`https://www.openstreetmap.org/?mlat=${emergency.lat}&mlon=${emergency.lng}#map=16/${emergency.lat}/${emergency.lng}`}
              target="_blank"
              rel="noreferrer"
            >
              VIEW LOCATION
            </a>
          ) : null}
        </div>

        {alarmRunning ? (
          <button type="button" className="btn btn-stop btn-xl" onClick={onStopAlarm}>
            STOP ALARM
          </button>
        ) : null}

        <button
          type="button"
          className={alreadyResponding ? "btn btn-ghost btn-xl" : "btn btn-primary btn-xl"}
          disabled={busy}
          onClick={onRespond}
        >
          {alreadyResponding ? "YOU ARE RESPONDING ✓" : "I'M RESPONDING"}
        </button>
      </div>
    </div>
  );
}

import { useCallback, useEffect, useRef, useState } from "react";
import { shortVibrate } from "./alarm";

const HOLD_MS = 3000;

/**
 * Emergency button. Requires ~3 seconds of continuous pressing.
 * Uses pointer events with touch-action:none so scrolling cannot break it,
 * and cancels immediately when the finger lifts.
 */
export function SosButton({
  disabled,
  onTrigger,
  onEarlyRelease,
}: {
  disabled?: boolean;
  onTrigger: () => void;
  onEarlyRelease: () => void;
}) {
  const [progress, setProgress] = useState(0);
  const startRef = useRef(0);
  const frameRef = useRef<number | null>(null);
  const holdingRef = useRef(false);
  const firedRef = useRef(false);

  const cancel = useCallback(() => {
    holdingRef.current = false;
    if (frameRef.current !== null) {
      cancelAnimationFrame(frameRef.current);
      frameRef.current = null;
    }
  }, []);

  useEffect(() => cancel, [cancel]);

  const loop = useCallback(() => {
    if (!holdingRef.current) return;
    const elapsed = performance.now() - startRef.current;
    const ratio = Math.min(1, elapsed / HOLD_MS);
    setProgress(ratio);
    if (ratio >= 1) {
      if (!firedRef.current) {
        firedRef.current = true;
        holdingRef.current = false;
        cancel();
        shortVibrate([120, 60, 120]);
        onTrigger();
      }
      return;
    }
    frameRef.current = requestAnimationFrame(loop);
  }, [cancel, onTrigger]);

  const start = useCallback(
    (event: React.PointerEvent<HTMLButtonElement>) => {
      if (disabled) return;
      event.preventDefault();
      // Capture the pointer so a small finger movement cannot cancel the hold.
      try {
        event.currentTarget.setPointerCapture(event.pointerId);
      } catch {
        /* ignore */
      }
      firedRef.current = false;
      holdingRef.current = true;
      startRef.current = performance.now();
      shortVibrate(25);
      if (frameRef.current !== null) cancelAnimationFrame(frameRef.current);
      frameRef.current = requestAnimationFrame(loop);
    },
    [disabled, loop],
  );

  const stop = useCallback(() => {
    if (!holdingRef.current) return;
    const elapsed = performance.now() - startRef.current;
    cancel();
    setProgress(0);
    if (elapsed < HOLD_MS) onEarlyRelease();
  }, [cancel, onEarlyRelease]);

  const angle = Math.round(progress * 360);

  return (
    <div className="sos-wrap">
      <button
        type="button"
        className={progress > 0 ? "sos sos-holding" : "sos"}
        style={{
          touchAction: "none",
          background: `conic-gradient(rgba(255,255,255,0.95) ${angle}deg, rgba(255,255,255,0.12) ${angle}deg)`,
        }}
        onPointerDown={start}
        onPointerUp={stop}
        onPointerCancel={stop}
        onContextMenu={(event) => event.preventDefault()}
        disabled={disabled}
        aria-label="Emergency: press and hold for 3 seconds"
      >
        <span className="sos-inner">
          <span className="sos-icon">🚨</span>
          <span className="sos-label">EMERGENCY</span>
          <span className="sos-hint">PRESS AND HOLD FOR 3 SECONDS</span>
          <span className="sos-count">{progress > 0 ? `${(progress * 3).toFixed(1)}s` : "3s"}</span>
        </span>
      </button>
    </div>
  );
}

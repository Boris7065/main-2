/**
 * Family SOS alarm engine.
 *
 * - Loud siren built with the Web Audio API (no audio file needed, works offline).
 * - Phone vibration using the Vibration API.
 * - Screen wake lock so the alert stays visible.
 *
 * The alarm always runs for `ALARM_DURATION_MS` (30s) unless the user presses
 * STOP ALARM. Audio is unlocked by the first user tap (browser requirement).
 */

export const ALARM_DURATION_MS = 30_000;

type AudioContextCtor = typeof AudioContext;

function getAudioContextCtor(): AudioContextCtor | null {
  const scope = globalThis as unknown as {
    AudioContext?: AudioContextCtor;
    webkitAudioContext?: AudioContextCtor;
  };
  return scope.AudioContext || scope.webkitAudioContext || null;
}

class AlarmEngine {
  private ctx: AudioContext | null = null;
  private osc: OscillatorNode | null = null;
  private sub: OscillatorNode | null = null;
  private gain: GainNode | null = null;
  private sirenTimer: ReturnType<typeof setInterval> | null = null;
  private vibrateTimer: ReturnType<typeof setInterval> | null = null;
  private stopTimer: ReturnType<typeof setTimeout> | null = null;
  private wakeLock: { release: () => Promise<void> } | null = null;
  private playing = false;

  get isPlaying() {
    return this.playing;
  }

  /** True when an AudioContext exists and is running (user has interacted). */
  get isReady() {
    return Boolean(this.ctx && this.ctx.state === "running");
  }

  /** Must be called from a user gesture (tap) the first time. */
  async unlock(): Promise<boolean> {
    const Ctor = getAudioContextCtor();
    if (!Ctor) return false;
    try {
      if (!this.ctx) this.ctx = new Ctor();
      if (this.ctx.state === "suspended") await this.ctx.resume();
      // Silent tick to fully unlock audio on iOS/Safari.
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      gain.gain.value = 0.0001;
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      osc.start();
      osc.stop(this.ctx.currentTime + 0.05);
      this.unlockVibration();
      return this.ctx.state === "running";
    } catch {
      return false;
    }
  }

  private unlockVibration() {
    const nav = navigator as Navigator & { vibrate?: (pattern: number | number[]) => boolean };
    if (typeof nav.vibrate === "function") {
      try {
        nav.vibrate(1);
      } catch {
        /* ignore */
      }
    }
  }

  async start(durationMs: number = ALARM_DURATION_MS) {
    if (this.playing) {
      this.scheduleAutoStop(durationMs);
      return;
    }
    this.playing = true;
    await this.unlock();
    this.startSiren();
    this.startVibration();
    this.requestWakeLock();
    this.scheduleAutoStop(durationMs);
  }

  private scheduleAutoStop(durationMs: number) {
    if (this.stopTimer) clearTimeout(this.stopTimer);
    this.stopTimer = setTimeout(() => {
      this.stop();
    }, Math.max(1000, durationMs));
  }

  private startSiren() {
    const ctx = this.ctx;
    if (!ctx || ctx.state !== "running") return;
    try {
      const gain = ctx.createGain();
      gain.gain.value = 0;
      gain.connect(ctx.destination);

      const osc = ctx.createOscillator();
      osc.type = "sawtooth";
      osc.frequency.value = 880;
      osc.connect(gain);

      const sub = ctx.createOscillator();
      sub.type = "square";
      sub.frequency.value = 440;
      const subGain = ctx.createGain();
      subGain.gain.value = 0.35;
      sub.connect(subGain);
      subGain.connect(gain);

      osc.start();
      sub.start();

      this.osc = osc;
      this.sub = sub;
      this.gain = gain;

      // Rising / falling two-tone emergency siren.
      const cycle = () => {
        if (!this.ctx || !this.osc || !this.gain) return;
        const t = this.ctx.currentTime;
        try {
          this.gain.gain.cancelScheduledValues(t);
          this.gain.gain.setValueAtTime(0.0001, t);
          this.gain.gain.linearRampToValueAtTime(0.55, t + 0.05);
          this.osc.frequency.cancelScheduledValues(t);
          this.osc.frequency.setValueAtTime(720, t);
          this.osc.frequency.linearRampToValueAtTime(1500, t + 0.45);
          this.osc.frequency.setValueAtTime(1500, t + 0.5);
          this.osc.frequency.linearRampToValueAtTime(680, t + 0.95);
          if (this.sub) {
            this.sub.frequency.setValueAtTime(360, t);
            this.sub.frequency.linearRampToValueAtTime(750, t + 0.45);
            this.sub.frequency.setValueAtTime(750, t + 0.5);
            this.sub.frequency.linearRampToValueAtTime(340, t + 0.95);
          }
        } catch {
          /* ignore */
        }
      };

      cycle();
      this.sirenTimer = setInterval(cycle, 1000);
    } catch {
      /* audio unavailable */
    }
  }

  private startVibration() {
    const nav = navigator as Navigator & { vibrate?: (pattern: number | number[]) => boolean };
    if (typeof nav.vibrate !== "function") return;
    const pattern = [600, 250, 600, 250, 1200, 500];
    const buzz = () => {
      try {
        nav.vibrate?.(pattern);
      } catch {
        /* ignore */
      }
    };
    buzz();
    this.vibrateTimer = setInterval(buzz, 3400);
  }

  private async requestWakeLock() {
    const nav = navigator as Navigator & {
      wakeLock?: { request: (type: string) => Promise<{ release: () => Promise<void> }> };
    };
    try {
      if (nav.wakeLock && !this.wakeLock) {
        this.wakeLock = await nav.wakeLock.request("screen");
      }
    } catch {
      /* ignore */
    }
  }

  stop() {
    this.playing = false;
    if (this.stopTimer) {
      clearTimeout(this.stopTimer);
      this.stopTimer = null;
    }
    if (this.sirenTimer) {
      clearInterval(this.sirenTimer);
      this.sirenTimer = null;
    }
    if (this.vibrateTimer) {
      clearInterval(this.vibrateTimer);
      this.vibrateTimer = null;
    }
    const nav = navigator as Navigator & { vibrate?: (pattern: number | number[]) => boolean };
    try {
      nav.vibrate?.(0);
    } catch {
      /* ignore */
    }
    try {
      this.gain?.gain.cancelScheduledValues(this.ctx?.currentTime ?? 0);
      this.gain?.gain.setValueAtTime(0, this.ctx?.currentTime ?? 0);
      this.osc?.stop();
      this.sub?.stop();
    } catch {
      /* ignore */
    }
    this.osc = null;
    this.sub = null;
    this.gain = null;
    if (this.wakeLock) {
      const lock = this.wakeLock;
      this.wakeLock = null;
      lock.release().catch(() => undefined);
    }
  }
}

export const alarm = new AlarmEngine();

export function shortVibrate(pattern: number | number[] = 40) {
  const nav = navigator as Navigator & { vibrate?: (pattern: number | number[]) => boolean };
  try {
    nav.vibrate?.(pattern);
  } catch {
    /* ignore */
  }
}

import type { Coords, Identity, SosEmergency, SosSnapshot } from "./types";

const STORAGE_KEY = "family-sos-identity-v1";

async function post<T>(url: string, body: unknown): Promise<T> {
  const response = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) {
    throw new Error(data?.error || "Something went wrong. Please try again.");
  }
  return data;
}

export async function patch<T>(url: string, body: unknown): Promise<T> {
  const response = await fetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
    cache: "no-store",
  });
  const data = (await response.json().catch(() => ({}))) as T & { error?: string };
  if (!response.ok) {
    throw new Error(data?.error || "Something went wrong. Please try again.");
  }
  return data;
}

export function createFamily(familyName: string, memberName: string) {
  return post<{ familyId: string; memberId: string; inviteCode: string }>("/api/families", {
    familyName,
    memberName,
  });
}

export function joinFamily(inviteCode: string, memberName: string) {
  return post<{ familyId: string; memberId: string; inviteCode: string }>("/api/families/join", {
    inviteCode,
    memberName,
  });
}

export async function fetchSnapshot(familyId: string, memberId: string): Promise<SosSnapshot | null> {
  const response = await fetch(
    `/api/state?familyId=${encodeURIComponent(familyId)}&memberId=${encodeURIComponent(memberId)}`,
    { cache: "no-store" },
  );
  if (!response.ok) return null;
  return (await response.json()) as SosSnapshot;
}

/** Location is always best-effort. It must never block an emergency. */
export function getLocation(timeoutMs = 5000): Promise<Coords | null> {
  return new Promise((resolve) => {
    if (typeof navigator === "undefined" || !navigator.geolocation) {
      resolve(null);
      return;
    }
    let settled = false;
    const finish = (value: Coords | null) => {
      if (settled) return;
      settled = true;
      resolve(value);
    };
    const timer = setTimeout(() => finish(null), timeoutMs);
    try {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          clearTimeout(timer);
          finish({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy:
              typeof position.coords.accuracy === "number" ? position.coords.accuracy : null,
          });
        },
        () => {
          clearTimeout(timer);
          finish(null);
        },
        { enableHighAccuracy: true, timeout: timeoutMs, maximumAge: 15_000 },
      );
    } catch {
      clearTimeout(timer);
      finish(null);
    }
  });
}

export function createEmergency(
  familyId: string,
  memberId: string,
  coords: { lat: number; lng: number; accuracy: number | null } | null,
) {
  return post<{ emergency: SosEmergency }>("/api/emergencies", {
    familyId,
    memberId,
    lat: coords ? coords.lat : null,
    lng: coords ? coords.lng : null,
    accuracy: coords ? coords.accuracy : null,
  });
}

export function markEmergencyStatus(emergencyId: string, memberId: string, status: "active" | "safe") {
  return patch<{ ok: boolean }>(`/api/emergencies/${emergencyId}`, {
    action: "status",
    memberId,
    status,
  });
}

export function respondToEmergency(
  emergencyId: string,
  memberId: string,
  memberName: string,
  response: "responding" | "seen",
) {
  return patch<{ ok: boolean }>(`/api/emergencies/${emergencyId}`, {
    action: "respond",
    memberId,
    memberName,
    response,
  });
}

export function savePushSubscription(memberId: string, subscription: PushSubscription) {
  return post<{ ok: boolean }>("/api/push", {
    memberId,
    subscription: subscription.toJSON(),
  });
}

export async function getVapidPublicKey(): Promise<string | null> {
  try {
    const response = await fetch("/api/push", { cache: "no-store" });
    const data = (await response.json()) as { publicKey?: string | null };
    return data.publicKey ?? null;
  } catch {
    return null;
  }
}

export function loadIdentity(): Identity | null {
  try {
    const raw = localStorage.getItem(STORAGE_KEY);
    if (!raw) return null;
    const parsed = JSON.parse(raw) as Identity;
    if (!parsed || !parsed.memberId || !parsed.familyId) return null;
    return parsed;
  } catch {
    return null;
  }
}

export function saveIdentity(identity: Identity) {
  try {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(identity));
  } catch {
    /* ignore */
  }
}

export function clearIdentity() {
  try {
    localStorage.removeItem(STORAGE_KEY);
  } catch {
    /* ignore */
  }
}

export function urlBase64ToUint8Array(base64String: string): Uint8Array<ArrayBuffer> {
  const padding = "=".repeat((4 - (base64String.length % 4)) % 4);
  const base64 = (base64String + padding).replace(/-/g, "+").replace(/_/g, "/");
  const raw = atob(base64);
  const output = new Uint8Array(new ArrayBuffer(raw.length));
  for (let i = 0; i < raw.length; i += 1) {
    output[i] = raw.charCodeAt(i);
  }
  return output;
}

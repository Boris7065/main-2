import { useState } from "react";
import type { SosEmergency, SosSnapshot } from "./types";
import {
  avatarColor,
  formatDate,
  formatDateTime,
  formatTime,
  initials,
  inviteLink,
  mapEmbedUrl,
  mapLink,
} from "./util";

const MAX_MEMBERS = 100;

export function Logo({ small }: { small?: boolean }) {
  return (
    <div className={small ? "logo logo-small" : "logo"}>
      <span className="logo-dot">🚨</span>
      <span className="logo-text">FAMILY SOS</span>
    </div>
  );
}

export function StartScreen({
  onCreate,
  onJoin,
}: {
  onCreate: () => void;
  onJoin: () => void;
}) {
  return (
    <div className="screen center">
      <Logo />
      <p className="tagline">
        One press alerts everyone in your family.
        <br />
        No account. No login. No setup.
      </p>
      <button type="button" className="btn btn-primary btn-xl" onClick={onCreate}>
        CREATE A FAMILY
      </button>
      <button type="button" className="btn btn-ghost btn-xl" onClick={onJoin}>
        JOIN A FAMILY
      </button>
      <p className="fineprint">Works on any phone. Your family invite code is your key.</p>
    </div>
  );
}

export function CreateScreen({
  busy,
  error,
  onSubmit,
  onBack,
}: {
  busy: boolean;
  error: string;
  onSubmit: (familyName: string, memberName: string) => void;
  onBack: () => void;
}) {
  const [familyName, setFamilyName] = useState("");
  const [memberName, setMemberName] = useState("");

  return (
    <div className="screen">
      <BackButton onBack={onBack} label="Back" />
      <h1 className="title">Create a family</h1>
      <p className="subtitle">Two details and you are done.</p>

      <form
        className="form"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit(familyName, memberName);
        }}
      >
        <label className="field">
          <span>Family name</span>
          <input
            value={familyName}
            onChange={(event) => setFamilyName(event.target.value)}
            placeholder="Johnson Family"
            autoComplete="organization"
            maxLength={60}
            required
          />
        </label>
        <label className="field">
          <span>Your name</span>
          <input
            value={memberName}
            onChange={(event) => setMemberName(event.target.value)}
            placeholder="John"
            autoComplete="name"
            maxLength={60}
            required
          />
        </label>
        {error ? <p className="error">{error}</p> : null}
        <button type="submit" className="btn btn-primary btn-xl" disabled={busy}>
          {busy ? "CREATING..." : "CREATE FAMILY"}
        </button>
      </form>
    </div>
  );
}

export function JoinScreen({
  busy,
  error,
  initialCode,
  onSubmit,
  onBack,
}: {
  busy: boolean;
  error: string;
  initialCode: string;
  onSubmit: (inviteCode: string, memberName: string) => void;
  onBack: () => void;
}) {
  const [memberName, setMemberName] = useState("");
  const [code, setCode] = useState(initialCode);

  return (
    <div className="screen">
      <BackButton onBack={onBack} label="Back" />
      <h1 className="title">Join a family</h1>
      <p className="subtitle">Enter the invite code your family shared with you.</p>

      <form
        className="form"
        onSubmit={(event) => {
          event.preventDefault();
          onSubmit(code, memberName);
        }}
      >
        <label className="field">
          <span>Your name</span>
          <input
            value={memberName}
            onChange={(event) => setMemberName(event.target.value)}
            placeholder="Sarah"
            autoComplete="name"
            maxLength={60}
            required
          />
        </label>
        <label className="field">
          <span>Family invite code or link</span>
          <input
            value={code}
            onChange={(event) => setCode(event.target.value)}
            placeholder="JHN-4829"
            autoCapitalize="characters"
            autoCorrect="off"
            spellCheck={false}
            maxLength={120}
            required
          />
        </label>
        {error ? <p className="error">{error}</p> : null}
        <button type="submit" className="btn btn-primary btn-xl" disabled={busy}>
          {busy ? "JOINING..." : "JOIN FAMILY"}
        </button>
      </form>
    </div>
  );
}

export async function copyText(text: string): Promise<boolean> {
  try {
    if (navigator.clipboard && window.isSecureContext) {
      await navigator.clipboard.writeText(text);
      return true;
    }
  } catch {
    /* fall through */
  }
  try {
    const area = document.createElement("textarea");
    area.value = text;
    area.setAttribute("readonly", "true");
    area.style.position = "fixed";
    area.style.opacity = "0";
    document.body.appendChild(area);
    area.select();
    const ok = document.execCommand("copy");
    document.body.removeChild(area);
    return ok;
  } catch {
    return false;
  }
}

export function CreatedScreen({
  familyName,
  inviteCode,
  onContinue,
}: {
  familyName: string;
  inviteCode: string;
  onContinue: () => void;
}) {
  const [copied, setCopied] = useState("");

  const copy = async (value: string, label: string) => {
    const ok = await copyText(value);
    setCopied(ok ? label : "");
    setTimeout(() => setCopied(""), 2200);
  };

  const share = async () => {
    const link = inviteLink(inviteCode);
    const text = `Join ${familyName} on Family SOS. Invite code: ${inviteCode} — ${link}`;
    const nav = navigator as Navigator & { share?: (data: ShareData) => Promise<void> };
    if (typeof nav.share === "function") {
      try {
        await nav.share({ title: "Family SOS invite", text });
        return;
      } catch {
        /* user cancelled - fall back to copy */
      }
    }
    await copy(text, "Invite copied");
  };

  return (
    <div className="screen center">
      <p className="ok-badge">FAMILY CREATED</p>
      <h1 className="title center-text">{familyName}</h1>
      <p className="subtitle">1 / {MAX_MEMBERS} Members</p>

      <div className="card code-card">
        <p className="card-label">INVITE CODE</p>
        <p className="invite-code">{inviteCode}</p>
        <p className="card-sub">Share this code with your family.</p>
        <div className="row">
          <button type="button" className="btn btn-ghost" onClick={() => copy(inviteCode, "Code copied")}>
            COPY CODE
          </button>
          <button type="button" className="btn btn-ghost" onClick={share}>
            SHARE INVITE
          </button>
        </div>
        {copied ? <p className="ok-note">{copied}</p> : null}
      </div>

      <button type="button" className="btn btn-primary btn-xl" onClick={onContinue}>
        GO TO MY FAMILY
      </button>
    </div>
  );
}

export function FamilyScreen({
  snapshot,
  myMemberId,
  onLeave,
}: {
  snapshot: SosSnapshot;
  myMemberId: string;
  onLeave: () => void;
}) {
  const [copied, setCopied] = useState("");
  const { family, members } = snapshot;

  const copy = async (value: string, label: string) => {
    const ok = await copyText(value);
    setCopied(ok ? label : "");
    setTimeout(() => setCopied(""), 2200);
  };

  const share = async () => {
    const link = inviteLink(family.inviteCode);
    const text = `Join ${family.name} on Family SOS. Invite code: ${family.inviteCode} — ${link}`;
    const nav = navigator as Navigator & { share?: (data: ShareData) => Promise<void> };
    if (typeof nav.share === "function") {
      try {
        await nav.share({ title: "Family SOS invite", text });
        return;
      } catch {
        /* ignore */
      }
    }
    await copy(text, "Invite copied");
  };

  return (
    <div className="screen">
      <h1 className="title">{family.name}</h1>
      <p className="subtitle">
        Members: {family.memberCount} / {family.maxMembers}
      </p>

      <div className="card code-card">
        <p className="card-label">INVITE CODE</p>
        <p className="invite-code">{family.inviteCode}</p>
        <div className="row">
          <button
            type="button"
            className="btn btn-ghost"
            onClick={() => copy(family.inviteCode, "Code copied")}
          >
            COPY INVITE CODE
          </button>
          <button type="button" className="btn btn-ghost" onClick={share}>
            SHARE INVITE
          </button>
        </div>
        {copied ? <p className="ok-note">{copied}</p> : null}
      </div>

      <h2 className="section-title">Family Members</h2>
      <ul className="member-list">
        {members.map((member) => (
          <li key={member.id} className="member-row">
            <span className="avatar" style={{ background: avatarColor(member.name) }}>
              {initials(member.name)}
            </span>
            <span className="member-name">
              {member.name}
              {member.id === myMemberId ? <em className="you"> (you)</em> : null}
            </span>
          </li>
        ))}
      </ul>

      <button type="button" className="btn btn-danger-ghost small" onClick={onLeave}>
        Leave this family
      </button>
    </div>
  );
}

export function HistoryScreen({ history }: { history: SosEmergency[] }) {
  if (history.length === 0) {
    return (
      <div className="screen">
        <h1 className="title">Emergency History</h1>
        <p className="subtitle">No alerts yet. That is good news.</p>
      </div>
    );
  }

  return (
    <div className="screen">
      <h1 className="title">Emergency History</h1>
      <p className="subtitle">{history.length} alert{history.length === 1 ? "" : "s"} recorded</p>
      <ul className="history-list">
        {history.map((item) => (
          <li key={item.id} className="history-row">
            <div className="history-head">
              <strong>{item.memberName} — Emergency</strong>
              <span className={item.status === "safe" ? "badge safe" : "badge active"}>
                {item.status === "safe" ? "Resolved" : "Active"}
              </span>
            </div>
            <p className="history-when">{formatDateTime(item.createdAt)}</p>
            {item.responses.length > 0 ? (
              <p className="history-resp">
                Responding: {item.responses.map((r) => r.name).join(", ")}
              </p>
            ) : null}
          </li>
        ))}
      </ul>
    </div>
  );
}

export function MapCard({ emergency }: { emergency: SosEmergency }) {
  if (typeof emergency.lat !== "number" || typeof emergency.lng !== "number") {
    return (
      <div className="card map-card empty">
        <p className="card-label">LOCATION</p>
        <p className="card-sub">No location was shared with this alert.</p>
      </div>
    );
  }

  return (
    <div className="card map-card">
      <p className="card-label">LOCATION</p>
      <iframe
        title="Emergency location"
        className="map"
        src={mapEmbedUrl(emergency.lat, emergency.lng)}
        loading="lazy"
      />
      <p className="coords">
        {emergency.lat.toFixed(5)}, {emergency.lng.toFixed(5)}
        {emergency.accuracy ? ` (±${Math.round(emergency.accuracy)}m)` : ""}
      </p>
      <a
        className="btn btn-ghost"
        href={mapLink(emergency.lat, emergency.lng)}
        target="_blank"
        rel="noreferrer"
      >
        VIEW LOCATION
      </a>
    </div>
  );
}

export function BackButton({ onBack, label }: { onBack: () => void; label: string }) {
  return (
    <button type="button" className="back" onClick={onBack}>
      ‹ {label}
    </button>
  );
}

export function MembersStrip({ snapshot }: { snapshot: SosSnapshot }) {
  return (
    <div className="members-strip">
      <p className="card-label">
        FAMILY MEMBERS — {snapshot.family.memberCount} / {snapshot.family.maxMembers}
      </p>
      <div className="chips">
        {snapshot.members.map((member) => (
          <span key={member.id} className="chip">
            {member.name}
          </span>
        ))}
      </div>
    </div>
  );
}

export { formatDate, formatTime, formatDateTime };

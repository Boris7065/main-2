/** Shared types for the Family SOS client. Framework agnostic. */

export type SosResponse = {
  memberId: string;
  name: string;
  response: string;
  at: string | null;
};

export type SosEmergency = {
  id: string;
  familyId: string;
  memberId: string;
  memberName: string;
  familyName?: string;
  status: "active" | "safe" | string;
  lat: number | null;
  lng: number | null;
  accuracy: number | null;
  createdAt: string | null;
  updatedAt?: string | null;
  resolvedAt: string | null;
  responses: SosResponse[];
};

export type SosMember = {
  id: string;
  name: string;
  joinedAt: string | null;
  lastSeenAt: string | null;
};

export type SosSnapshot = {
  family: {
    id: string;
    name: string;
    inviteCode: string;
    maxMembers: number;
    memberCount: number;
  };
  members: SosMember[];
  active: SosEmergency[];
  history: SosEmergency[];
};

export type Identity = {
  memberId: string;
  familyId: string;
  name: string;
  familyName?: string;
  inviteCode?: string;
};

export type Coords = {
  lat: number;
  lng: number;
  accuracy: number | null;
};

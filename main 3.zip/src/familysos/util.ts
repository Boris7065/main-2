export function formatTime(iso: string | null): string {
  if (!iso) return "--:--";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "--:--";
  return date.toLocaleTimeString(undefined, { hour: "numeric", minute: "2-digit" });
}

export function formatDate(iso: string | null): string {
  if (!iso) return "—";
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return "—";
  return date.toLocaleDateString(undefined, {
    year: "numeric",
    month: "long",
    day: "numeric",
  });
}

export function formatDateTime(iso: string | null): string {
  if (!iso) return "—";
  return `${formatDate(iso)} — ${formatTime(iso)}`;
}

export function elapsedLabel(iso: string | null, now: number): string {
  if (!iso) return "";
  const start = new Date(iso).getTime();
  if (Number.isNaN(start)) return "";
  const seconds = Math.max(0, Math.floor((now - start) / 1000));
  const minutes = Math.floor(seconds / 60);
  const rest = seconds % 60;
  if (minutes <= 0) return `${rest}s ago`;
  if (minutes < 60) return `${minutes}m ${rest}s ago`;
  const hours = Math.floor(minutes / 60);
  return `${hours}h ${minutes % 60}m ago`;
}

export function mapEmbedUrl(lat: number, lng: number): string {
  const box = 0.004;
  return `https://www.openstreetmap.org/export/embed.html?bbox=${lng - box}%2C${lat - box}%2C${
    lng + box
  }%2C${lat + box}&layer=mapnik&marker=${lat}%2C${lng}`;
}

export function mapLink(lat: number, lng: number): string {
  const isApple = /iPhone|iPad|iPod|Macintosh/.test(navigator.userAgent || "");
  return isApple
    ? `https://maps.apple.com/?q=${lat},${lng}&ll=${lat},${lng}`
    : `https://www.google.com/maps?q=${lat},${lng}`;
}

export function inviteLink(code: string): string {
  const origin = typeof window !== "undefined" ? window.location.origin : "";
  return `${origin}/?join=${encodeURIComponent(code)}`;
}

export function initials(name: string): string {
  const parts = String(name || "").trim().split(/\s+/).slice(0, 2);
  return parts.map((part) => part.charAt(0).toUpperCase()).join("") || "?";
}

export function avatarColor(name: string): string {
  const palette = ["#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4", "#6366f1", "#a855f7", "#ec4899"];
  let hash = 0;
  for (let i = 0; i < name.length; i += 1) hash = (hash * 31 + name.charCodeAt(i)) % 9973;
  return palette[hash % palette.length];
}

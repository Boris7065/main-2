/** Type surface for the framework-free backend core (core.mjs). */

export declare const MAX_MEMBERS: number;
export declare const pool: unknown;

export declare function normalizeCode(raw: unknown): string;
export declare function getVapidPublicKey(): Promise<string | null>;
export declare function savePushSubscription(
  memberId: string,
  subscription: {
    endpoint?: string;
    keys?: { p256dh?: string; auth?: string };
  },
): Promise<void>;

export declare function createFamily(input: {
  familyName?: unknown;
  memberName?: unknown;
}): Promise<{
  error?: string;
  status?: number;
  familyId?: string;
  memberId?: string;
  inviteCode?: string;
}>;

export declare function joinFamily(input: {
  inviteCode?: unknown;
  memberName?: unknown;
}): Promise<{
  error?: string;
  status?: number;
  familyId?: string;
  memberId?: string;
  inviteCode?: string;
}>;

export interface SosResponse {
  memberId: string;
  name: string;
  response: string;
  at: string | null;
}

export interface SosEmergency {
  id: string;
  familyId: string;
  memberId: string;
  memberName: string;
  familyName?: string;
  status: string;
  lat: number | null;
  lng: number | null;
  accuracy: number | null;
  createdAt: string | null;
  updatedAt?: string | null;
  resolvedAt: string | null;
  responses: SosResponse[];
}

export interface SosMember {
  id: string;
  name: string;
  joinedAt: string | null;
  lastSeenAt: string | null;
}

export interface SosSnapshot {
  family: {
    id: string;
    name: string;
    inviteCode: string;
    maxMembers: number;
    memberCount: number;
  };
  members: SosMember[];
  active: SosEmergency[];
  history: SosEmergency[];
}

export declare function getSnapshot(familyId: string): Promise<SosSnapshot | null>;
export declare function touchMember(memberId: string): Promise<void>;

export declare function createEmergency(input: {
  familyId?: unknown;
  memberId?: unknown;
  lat?: unknown;
  lng?: unknown;
  accuracy?: unknown;
}): Promise<{ error?: string; status?: number; emergency?: SosEmergency }>;

export declare function setEmergencyStatus(input: {
  emergencyId: string;
  memberId?: string;
  status: string;
}): Promise<{ error?: string; status?: number; ok?: boolean; status2?: string }>;

export declare function addResponse(input: {
  emergencyId: string;
  memberId: string;
  memberName?: string;
  response: string;
}): Promise<{ ok: boolean }>;

export declare function getFamilyVersion(familyId: string): Promise<string>;

/**
 * Family SOS - framework-free backend core.
 *
 * Plain Node ESM so that it can be used by:
 *   1. The Next.js route handlers in this sandbox preview.
 *   2. `standalone/server.mjs`, the minimal Node http server used by the
 *      Catalina-compatible Vite project (`npm install && npm run dev`).
 *
 * Only `pg` (pure JavaScript) is required - no native binaries.
 */

import crypto from "node:crypto";
import pg from "pg";

const DATABASE_URL = process.env.DATABASE_URL;

if (!DATABASE_URL) {
  throw new Error("DATABASE_URL is required");
}

const globalForDb = globalThis;

function createPool() {
  return new pg.Pool({
    connectionString: DATABASE_URL,
    max: 10,
    idleTimeoutMillis: 30_000,
    connectionTimeoutMillis: 10_000,
  });
}

export const pool = globalForDb.__familySosPool ?? createPool();
globalForDb.__familySosPool = pool;

export const MAX_MEMBERS = 100;

const CODE_LETTERS = "ABCDEFGHJKLMNPQRSTUVWXYZ";

function makeInviteCode() {
  let letters = "";
  for (let i = 0; i < 3; i += 1) {
    letters += CODE_LETTERS[crypto.randomInt(0, CODE_LETTERS.length)];
  }
  const digits = String(crypto.randomInt(0, 10000)).padStart(4, "0");
  return `${letters}-${digits}`;
}

export function normalizeCode(raw) {
  if (!raw) return "";
  let value = String(raw).trim();
  // Accept a full invite link (https://host/?code=JHN-4829 or ?join=JHN-4829)
  const link = value.match(/[?&](?:code|join)=([A-Za-z0-9-]{4,20})/i);
  if (link) value = link[1];
  // Accept pasted share text such as "Invite code: JHN-4829"
  const inside = value.match(/\b([A-Za-z]{3}-\d{4})\b/);
  if (inside) value = inside[1];
  value = value.replace(/[^a-zA-Z0-9-]/g, "").toUpperCase();
  if (!value.includes("-") && value.length > 3) {
    value = `${value.slice(0, 3)}-${value.slice(3)}`;
  }
  return value;
}

function cleanName(raw, fallback) {
  const value = String(raw ?? "").replace(/\s+/g, " ").trim();
  return value ? value.slice(0, 60) : fallback || "";
}

function iso(value) {
  return value ? new Date(value).toISOString() : null;
}

/* ------------------------------------------------------------------ */
/* Push notifications (real Web Push, graceful no-op when unavailable) */
/* ------------------------------------------------------------------ */

let webPush = null;
try {
  webPush = (await import("web-push")).default;
} catch {
  webPush = null;
}

async function getVapidKeys() {
  const envPublic = process.env.VAPID_PUBLIC_KEY;
  const envPrivate = process.env.VAPID_PRIVATE_KEY;
  if (envPublic && envPrivate) {
    return { publicKey: envPublic, privateKey: envPrivate };
  }
  if (!webPush) return null;
  const existing = await pool.query("SELECT public_key, private_key FROM push_keys WHERE id = 1");
  if (existing.rows.length > 0) {
    return { publicKey: existing.rows[0].public_key, privateKey: existing.rows[0].private_key };
  }
  const generated = webPush.generateVAPIDKeys();
  await pool.query(
    "INSERT INTO push_keys (id, public_key, private_key) VALUES (1, $1, $2) ON CONFLICT (id) DO NOTHING",
    [generated.publicKey, generated.privateKey],
  );
  return { publicKey: generated.publicKey, privateKey: generated.privateKey };
}

export async function getVapidPublicKey() {
  const keys = await getVapidKeys();
  return keys ? keys.publicKey : null;
}

export async function savePushSubscription(memberId, subscription) {
  if (!subscription || !subscription.endpoint) return;
  const keys = subscription.keys || {};
  if (!keys.p256dh || !keys.auth) return;
  await pool.query(
    `INSERT INTO push_subscriptions (member_id, endpoint, p256dh, auth)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (endpoint) DO UPDATE SET member_id = EXCLUDED.member_id, p256dh = EXCLUDED.p256dh, auth = EXCLUDED.auth`,
    [memberId, String(subscription.endpoint).slice(0, 900), keys.p256dh, keys.auth],
  );
}

async function sendPushToFamily(familyId, excludeMemberId, payload) {
  if (!webPush) return;
  let keys;
  try {
    keys = await getVapidKeys();
  } catch {
    return;
  }
  if (!keys) return;
  webPush.setVapidDetails("mailto:alerts@family-sos.local", keys.publicKey, keys.privateKey);

  let rows;
  try {
    rows = await pool.query(
      `SELECT DISTINCT endpoint, p256dh, auth FROM push_subscriptions
       WHERE member_id IN (SELECT id FROM members WHERE family_id = $1) AND member_id <> $2`,
      [familyId, excludeMemberId || ""],
    );
  } catch {
    return;
  }

  const body = JSON.stringify(payload);
  await Promise.all(
    rows.rows.map(async (row) => {
      try {
        await webPush.sendNotification(
          {
            endpoint: row.endpoint,
            keys: { p256dh: row.p256dh, auth: row.auth },
          },
          body,
          { TTL: 120, urgency: "high" },
        );
      } catch (error) {
        const status = error && error.statusCode;
        if (status === 404 || status === 410) {
          await pool.query("DELETE FROM push_subscriptions WHERE endpoint = $1", [row.endpoint]);
        }
      }
    }),
  );
}

/* ------------------------------------------------------------------ */
/* Families                                                            */
/* ------------------------------------------------------------------ */

export async function createFamily({ familyName, memberName }) {
  const family = cleanName(familyName);
  const member = cleanName(memberName);
  if (!family) return { error: "Please enter a family name.", status: 400 };
  if (!member) return { error: "Please enter your name.", status: 400 };

  let code = makeInviteCode();
  for (let attempt = 0; attempt < 8; attempt += 1) {
    const clash = await pool.query("SELECT 1 FROM families WHERE invite_code = $1", [code]);
    if (clash.rows.length === 0) break;
    code = makeInviteCode();
  }

  const familyId = crypto.randomUUID();
  const memberId = crypto.randomUUID();
  const client = await pool.connect();
  try {
    await client.query("BEGIN");
    await client.query(
      "INSERT INTO families (id, name, invite_code, max_members) VALUES ($1, $2, $3, $4)",
      [familyId, family, code, MAX_MEMBERS],
    );
    await client.query("INSERT INTO members (id, family_id, name) VALUES ($1, $2, $3)", [
      memberId,
      familyId,
      member,
    ]);
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }

  return { familyId, memberId, inviteCode: code };
}

export async function joinFamily({ inviteCode, memberName }) {
  const member = cleanName(memberName);
  const code = normalizeCode(inviteCode);
  if (!member) return { error: "Please enter your name.", status: 400 };
  if (!code) return { error: "Please enter the family invite code.", status: 400 };

  const familyResult = await pool.query(
    "SELECT id, name, max_members FROM families WHERE invite_code = $1",
    [code],
  );
  if (familyResult.rows.length === 0) {
    return { error: "That invite code was not found. Please check it and try again.", status: 404 };
  }
  const family = familyResult.rows[0];

  const client = await pool.connect();
  let memberId = null;
  try {
    await client.query("BEGIN");
    const locked = await client.query(
      "SELECT id, name, max_members FROM families WHERE id = $1 FOR UPDATE",
      [family.id],
    );
    const count = await client.query("SELECT count(*)::int AS total FROM members WHERE family_id = $1", [
      family.id,
    ]);
    const total = count.rows[0].total;
    if (total >= locked.rows[0].max_members) {
      await client.query("ROLLBACK");
      return { error: "This family is full. Maximum 100 members allowed.", status: 409 };
    }
    // Re-join with the same name reuses the existing member row so that
    // clearing browser storage does not create duplicate people.
    const existing = await client.query(
      "SELECT id FROM members WHERE family_id = $1 AND lower(name) = lower($2) ORDER BY joined_at LIMIT 1",
      [family.id, member],
    );
    if (existing.rows.length > 0) {
      memberId = existing.rows[0].id;
      await client.query("UPDATE members SET last_seen_at = now() WHERE id = $1", [memberId]);
    } else {
      memberId = crypto.randomUUID();
      await client.query("INSERT INTO members (id, family_id, name) VALUES ($1, $2, $3)", [
        memberId,
        family.id,
        member,
      ]);
    }
    await client.query("COMMIT");
  } catch (error) {
    await client.query("ROLLBACK");
    throw error;
  } finally {
    client.release();
  }

  return { familyId: family.id, memberId, inviteCode: code };
}

/* ------------------------------------------------------------------ */
/* Snapshot (family + members + emergencies)                           */
/* ------------------------------------------------------------------ */

export async function getSnapshot(familyId) {
  const familyResult = await pool.query(
    "SELECT id, name, invite_code, max_members FROM families WHERE id = $1",
    [familyId],
  );
  if (familyResult.rows.length === 0) return null;
  const family = familyResult.rows[0];

  const membersResult = await pool.query(
    "SELECT id, name, joined_at, last_seen_at FROM members WHERE family_id = $1 ORDER BY joined_at ASC, name ASC",
    [familyId],
  );

  const emergencyResult = await pool.query(
    `SELECT id, member_id, member_name, status, lat, lng, accuracy, created_at, updated_at, resolved_at
     FROM emergencies WHERE family_id = $1 ORDER BY created_at DESC LIMIT 60`,
    [familyId],
  );

  const ids = emergencyResult.rows.map((row) => row.id);
  let responses = [];
  if (ids.length > 0) {
    const responseResult = await pool.query(
      `SELECT emergency_id, member_id, member_name, response, created_at
       FROM emergency_responses WHERE emergency_id = ANY($1::uuid[]) ORDER BY created_at ASC`,
      [ids],
    );
    responses = responseResult.rows;
  }

  const byEmergency = new Map();
  for (const row of responses) {
    const list = byEmergency.get(row.emergency_id) || [];
    list.push({
      memberId: row.member_id,
      name: row.member_name,
      response: row.response,
      at: iso(row.created_at),
    });
    byEmergency.set(row.emergency_id, list);
  }

  const allEmergencies = emergencyResult.rows.map((row) => ({
    id: row.id,
    familyId: row.family_id,
    memberId: row.member_id,
    memberName: row.member_name,
    status: row.status,
    lat: row.lat,
    lng: row.lng,
    accuracy: row.accuracy,
    createdAt: iso(row.created_at),
    updatedAt: iso(row.updated_at),
    resolvedAt: iso(row.resolved_at),
    responses: byEmergency.get(row.id) || [],
  }));

  return {
    family: {
      id: family.id,
      name: family.name,
      inviteCode: family.invite_code,
      maxMembers: family.max_members,
      memberCount: membersResult.rows.length,
    },
    members: membersResult.rows.map((row) => ({
      id: row.id,
      name: row.name,
      joinedAt: iso(row.joined_at),
      lastSeenAt: iso(row.last_seen_at),
    })),
    active: allEmergencies.filter((item) => item.status === "active"),
    history: allEmergencies,
  };
}

export async function touchMember(memberId) {
  if (!memberId) return;
  try {
    await pool.query("UPDATE members SET last_seen_at = now() WHERE id = $1", [memberId]);
  } catch {
    /* non critical */
  }
}

/* ------------------------------------------------------------------ */
/* Emergencies                                                         */
/* ------------------------------------------------------------------ */

function num(value) {
  const parsed = Number(value);
  return Number.isFinite(parsed) ? parsed : null;
}

export async function createEmergency({ familyId, memberId, lat, lng, accuracy }) {
  if (!familyId || !memberId) return { error: "Missing family or member.", status: 400 };

  const memberResult = await pool.query(
    `SELECT m.id, m.name, f.id AS family_id, f.name AS family_name
     FROM members m JOIN families f ON f.id = m.family_id WHERE m.id = $1 AND m.family_id = $2`,
    [memberId, familyId],
  );
  if (memberResult.rows.length === 0) return { error: "Member not found.", status: 404 };
  const member = memberResult.rows[0];

  // Never allow location problems to block an alert: values are optional.
  const emergencyId = crypto.randomUUID();
  const result = await pool.query(
    `INSERT INTO emergencies (id, family_id, member_id, member_name, status, lat, lng, accuracy)
     VALUES ($1, $2, $3, $4, 'active', $5, $6, $7) RETURNING created_at`,
    [
      emergencyId,
      familyId,
      memberId,
      member.name,
      num(lat),
      num(lng),
      num(accuracy),
    ],
  );

  const createdAt = iso(result.rows[0].created_at);

  await sendPushToFamily(familyId, memberId, {
    type: "emergency",
    emergencyId,
    memberId,
    memberName: member.name,
    familyName: member.family_name,
    createdAt,
    lat: num(lat),
    lng: num(lng),
  });

  return {
    emergency: {
      id: emergencyId,
      familyId,
      memberId,
      memberName: member.name,
      familyName: member.family_name,
      status: "active",
      lat: num(lat),
      lng: num(lng),
      accuracy: num(accuracy),
      createdAt,
      resolvedAt: null,
      responses: [],
    },
  };
}

export async function setEmergencyStatus({ emergencyId, memberId, status }) {
  const next = status === "safe" ? "safe" : "active";
  const result = await pool.query(
    `UPDATE emergencies SET status = $1, updated_at = now(),
       resolved_at = CASE WHEN $1 = 'safe' THEN now() ELSE NULL END
     WHERE id = $2 RETURNING family_id, member_id, member_name`,
    [next, emergencyId],
  );
  if (result.rows.length === 0) return { error: "Emergency not found.", status: 404 };
  const row = result.rows[0];

  await sendPushToFamily(row.family_id, memberId, {
    type: next === "safe" ? "safe" : "emergency",
    emergencyId,
    memberId: row.member_id,
    memberName: row.member_name,
    status: next,
  });

  if (next === "safe") {
    await pool.query("DELETE FROM emergency_responses WHERE emergency_id = $1", [emergencyId]);
  }
  return { ok: true, status: next };
}

export async function addResponse({ emergencyId, memberId, memberName, response }) {
  const name = cleanName(memberName) || "A family member";
  const kind = response === "responding" ? "responding" : "seen";
  await pool.query(
    `INSERT INTO emergency_responses (emergency_id, member_id, member_name, response)
     VALUES ($1, $2, $3, $4)
     ON CONFLICT (emergency_id, member_id) DO UPDATE SET response = EXCLUDED.response, created_at = now()`,
    [emergencyId, memberId, name, kind],
  );
  return { ok: true };
}

/* ------------------------------------------------------------------ */
/* SSE wait loop helper: cheap change detection                        */
/* ------------------------------------------------------------------ */

export async function getFamilyVersion(familyId) {
  const result = await pool.query(
    `SELECT greatest(
       (SELECT coalesce(max(updated_at), to_timestamp(0)) FROM emergencies WHERE family_id = $1),
       (SELECT coalesce(max(joined_at), to_timestamp(0)) FROM members WHERE family_id = $1),
       (SELECT coalesce(max(r.created_at), to_timestamp(0)) FROM emergency_responses r
          JOIN emergencies e ON e.id = r.emergency_id WHERE e.family_id = $1)
     ) AS version`,
    [familyId],
  );
  const row = result.rows[0];
  return row ? String(new Date(row.version).getTime()) : "0";
}

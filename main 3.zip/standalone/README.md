# Family SOS — standalone React + Vite project (macOS Catalina friendly)

One press alerts everyone in your family. No accounts, no login.

This folder is a **self-contained** React project that runs on **Intel x86_64 Macs running
macOS 10.15 Catalina**:

* React 18 + Vite 4.3 (esbuild 0.17 — works on Catalina, no macOS 11+ requirement)
* Plain JavaScript / HTML / CSS. No Turbopack, no Next.js, no experimental packages.
* Backend = `server.mjs`: plain Node `http` + `pg` (pure JavaScript, no native binaries).
* Real database = PostgreSQL. Real-time = Server-Sent Events. Real notifications = Web Push.

## Requirements

* Node.js 16 or newer (`node -v`)
* PostgreSQL 13 or newer running locally

## Setup

```bash
cd standalone
cp .env.example .env          # then edit DATABASE_URL if needed
createdb family_sos           # or use an existing database

# create the tables (psql)
psql "$DATABASE_URL" -f schema.sql

npm install
npm run dev
```

Open the printed URL (default <http://localhost:5173>) on your phone and your computer.

`npm run dev` starts two things:

1. `node server.mjs` — the API on port **8787**
2. `vite` — the React app on port **5173** (proxies `/api` to 8787)

Production-style single process (builds the app, then serves it + API on port 8787):

```bash
npm run start      # http://localhost:8787
```

## How it works

| Screen | What it does |
| --- | --- |
| Start | **CREATE A FAMILY** / **JOIN A FAMILY** — no login. |
| Create | Family name + your name → generates an invite code (e.g. `JHN-4829`), Copy Code + Share Invite. |
| Join | Your name + invite code (or a full invite link) → added to that family. |
| Home | Family name, `Members: n / 100`, every member listed, and one huge 🚨 EMERGENCY button that needs a **3 second hold**. |
| Emergency | Everyone else in the family gets a Web Push notification, a **loud siren + vibration for 30 seconds**, and the emergency screen (name, family, time, location + map). |
| Buttons | **CALL** · **VIEW LOCATION** · **STOP ALARM** · **I'M RESPONDING** |
| Status | The person who triggered it can switch between **ACTIVE** and **SAFE**. SAFE notifies everyone: “[Name] has marked themselves SAFE.” |
| Family | Family name, member count, all members, invite code, Copy / Share. |
| History | Every past alert: person, date, time, status (Active / Resolved). |

### Location

Location is requested when the button is triggered. If permission is granted the coordinates
are attached to the alert; if it is denied (or times out) **the alert is still sent** — location
can never block an emergency.

### Reliability notes

* The alert POST is retried up to 3 times.
* Every client holds a live SSE stream (`/api/stream`) and automatically falls back to
  2-second polling if the stream is blocked.
* The maximum of **100 members per family** is enforced in a row-locked transaction, so the
  101st member is rejected with “This family is full. Maximum 100 members allowed.”
* Alarm sound uses the Web Audio API and needs one tap to unlock (the app shows a
  “Tap to turn on alarm sound & notifications” banner). Add the app to your home screen
  (Share → Add to Home Screen) for the most reliable alarms and push notifications.

## Files

```
index.html            Vite entry
main.jsx              React bootstrap
vite.config.js        Vite 4 + /api proxy
server.mjs            Node API + static file server (no frameworks)
schema.sql            PostgreSQL tables
src/app/              React app (App, screens, SOS button, alarm engine)
src/server/core.mjs   All database / emergency / push logic (shared, framework-free)
public/               service worker, manifest, icon
```

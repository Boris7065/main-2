import React from "react";
import { createRoot } from "react-dom/client";
import App from "./src/app/App";
import "./src/app/app.css";

createRoot(document.getElementById("root")).render(React.createElement(App));

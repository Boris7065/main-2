-- Family SOS — PostgreSQL schema
-- Apply with:  psql "$DATABASE_URL" -f schema.sql

CREATE EXTENSION IF NOT EXISTS pgcrypto;

CREATE TABLE IF NOT EXISTS families (
  id uuid PRIMARY KEY,
  name text NOT NULL,
  invite_code text NOT NULL,
  max_members integer NOT NULL DEFAULT 100,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS families_invite_code_idx ON families (invite_code);

CREATE TABLE IF NOT EXISTS members (
  id uuid PRIMARY KEY,
  family_id uuid NOT NULL REFERENCES families (id) ON DELETE CASCADE,
  name text NOT NULL,
  joined_at timestamptz NOT NULL DEFAULT now(),
  last_seen_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS members_family_idx ON members (family_id);

CREATE TABLE IF NOT EXISTS emergencies (
  id uuid PRIMARY KEY,
  family_id uuid NOT NULL REFERENCES families (id) ON DELETE CASCADE,
  member_id uuid NOT NULL,
  member_name text NOT NULL,
  status text NOT NULL DEFAULT 'active',
  lat double precision,
  lng double precision,
  accuracy double precision,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  resolved_at timestamptz
);

CREATE INDEX IF NOT EXISTS emergencies_family_idx ON emergencies (family_id);

CREATE TABLE IF NOT EXISTS emergency_responses (
  id serial PRIMARY KEY,
  emergency_id uuid NOT NULL REFERENCES emergencies (id) ON DELETE CASCADE,
  member_id uuid NOT NULL,
  member_name text NOT NULL,
  response text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS emergency_responses_unique
  ON emergency_responses (emergency_id, member_id);

CREATE TABLE IF NOT EXISTS push_subscriptions (
  id serial PRIMARY KEY,
  member_id uuid NOT NULL,
  endpoint text NOT NULL,
  p256dh text NOT NULL,
  auth text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE UNIQUE INDEX IF NOT EXISTS push_subscriptions_endpoint_idx
  ON push_subscriptions (endpoint);

CREATE TABLE IF NOT EXISTS push_keys (
  id integer PRIMARY KEY,
  public_key text NOT NULL,
  private_key text NOT NULL
);

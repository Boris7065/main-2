/**
 * Family SOS — minimal Node HTTP server (no frameworks, no native binaries).
 *
 * Serves:
 *   - the JSON API (same endpoints as the hosted version)
 *   - the built React app from ./dist
 *   - /sw.js, /manifest.webmanifest, /icon.svg from ./public
 *
 * Run with:  node server.mjs     (default port 8787)
 */

import http from "node:http";
import fs from "node:fs";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));

/* tiny .env loader (avoids a dependency) */
for (const envFile of [path.join(__dirname, ".env"), path.join(__dirname, "..", ".env")]) {
  try {
    const raw = fs.readFileSync(envFile, "utf8");
    for (const line of raw.split("\n")) {
      const match = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
      if (match && !process.env[match[1]]) {
        process.env[match[1]] = match[2].replace(/^["']|["']$/g, "");
      }
    }
  } catch {
    /* no .env file here */
  }
}

/* Imported dynamically so the .env file above is loaded first. */
const {
  addResponse,
  createEmergency,
  createFamily,
  getFamilyVersion,
  getSnapshot,
  getVapidPublicKey,
  joinFamily,
  savePushSubscription,
  setEmergencyStatus,
} = await import("./src/server/core.mjs");

if (!process.env.DATABASE_URL) {
  console.error("DATABASE_URL is required. Create standalone/.env with your Postgres connection.");
  process.exit(1);
}

const PORT = Number(process.env.PORT || 8787);
const DIST = path.join(__dirname, "dist");
const PUBLIC = path.join(__dirname, "public");

const MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".svg": "image/svg+xml",
  ".json": "application/json",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".ico": "image/x-icon",
  ".webmanifest": "application/manifest+json",
};

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, {
    "Content-Type": "application/json; charset=utf-8",
    "Cache-Control": "no-store",
  });
  res.end(body);
}

async function readBody(req) {
  const chunks = [];
  for await (const chunk of req) chunks.push(chunk);
  const raw = Buffer.concat(chunks).toString("utf8");
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

async function handleApi(req, res, url) {
  const { pathname } = url;

  if (pathname === "/api/health") {
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === "/api/push" && req.method === "GET") {
    const publicKey = await getVapidPublicKey();
    return sendJson(res, 200, { publicKey });
  }

  if (pathname === "/api/push" && req.method === "POST") {
    const body = await readBody(req);
    await savePushSubscription(body.memberId, body.subscription);
    return sendJson(res, 200, { ok: true });
  }

  if (pathname === "/api/families" && req.method === "POST") {
    const body = await readBody(req);
    const result = await createFamily({
      familyName: body.familyName,
      memberName: body.memberName,
    });
    return sendJson(res, result.error ? result.status || 400 : 201, result);
  }

  if (pathname === "/api/families/join" && req.method === "POST") {
    const body = await readBody(req);
    const result = await joinFamily({ inviteCode: body.inviteCode, memberName: body.memberName });
    return sendJson(res, result.error ? result.status || 400 : 201, result);
  }

  if (pathname === "/api/state" && req.method === "GET") {
    const familyId = url.searchParams.get("familyId") || "";
    const snapshot = await getSnapshot(familyId);
    if (!snapshot) return sendJson(res, 404, { error: "Family not found" });
    return sendJson(res, 200, snapshot);
  }

  if (pathname === "/api/emergencies" && req.method === "POST") {
    const body = await readBody(req);
    const result = await createEmergency({
      familyId: body.familyId,
      memberId: body.memberId,
      lat: body.lat,
      lng: body.lng,
      accuracy: body.accuracy,
    });
    return sendJson(res, result.error ? result.status || 400 : 201, result);
  }

  if (pathname.startsWith("/api/emergencies/") && req.method === "PATCH") {
    const id = pathname.split("/")[3];
    const body = await readBody(req);
    if (body.action === "status") {
      const result = await setEmergencyStatus({
        emergencyId: id,
        memberId: body.memberId,
        status: body.status,
      });
      return sendJson(res, result.error ? result.status || 400 : 200, result);
    }
    if (body.action === "respond") {
      await addResponse({
        emergencyId: id,
        memberId: body.memberId,
        memberName: body.memberName,
        response: body.response,
      });
      return sendJson(res, 200, { ok: true });
    }
    return sendJson(res, 400, { error: "Unknown action" });
  }

  if (pathname === "/api/stream" && req.method === "GET") {
    const familyId = url.searchParams.get("familyId") || "";
    res.writeHead(200, {
      "Content-Type": "text/event-stream; charset=utf-8",
      "Cache-Control": "no-cache, no-transform",
      Connection: "keep-alive",
    });
    res.write("retry: 2000\n\n");
    let lastVersion = "";
    let closed = false;
    req.on("close", () => {
      closed = true;
    });
    const tick = async () => {
      if (closed) return;
      try {
        const version = await getFamilyVersion(familyId);
        if (version !== lastVersion) {
          lastVersion = version;
          const snapshot = await getSnapshot(familyId);
          if (!snapshot) {
            closed = true;
            res.end();
            return;
          }
          res.write(`event: snapshot\ndata: ${JSON.stringify(snapshot)}\n\n`);
        } else {
          res.write(`: ping\n\n`);
        }
      } catch {
        /* keep the stream alive */
      }
      setTimeout(tick, 1500).unref?.();
    };
    tick();
    return;
  }

  sendJson(res, 404, { error: "Not found" });
}

function serveFile(res, filePath) {
  fs.readFile(filePath, (error, data) => {
    if (error) {
      res.writeHead(404, { "Content-Type": "text/plain" });
      res.end("Not found");
      return;
    }
    res.writeHead(200, {
      "Content-Type": MIME[path.extname(filePath)] || "application/octet-stream",
      "Cache-Control": filePath.includes("sw.js") ? "no-cache" : "public, max-age=3600",
    });
    res.end(data);
  });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || "localhost"}`);
  try {
    if (url.pathname.startsWith("/api/")) {
      await handleApi(req, res, url);
      return;
    }

    let file = url.pathname === "/" ? "/index.html" : url.pathname;
    const publicPath = path.join(PUBLIC, file);
    if (fs.existsSync(publicPath) && fs.statSync(publicPath).isFile()) {
      serveFile(res, publicPath);
      return;
    }
    const distPath = path.join(DIST, file);
    if (fs.existsSync(distPath) && fs.statSync(distPath).isFile()) {
      serveFile(res, distPath);
      return;
    }
    serveFile(res, path.join(DIST, "index.html"));
  } catch (error) {
    console.error(error);
    sendJson(res, 500, { error: "Server error" });
  }
});

server.listen(PORT, () => {
  console.log(`Family SOS API + app running on http://localhost:${PORT}`);
});

import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";

// Catalina-friendly: Vite 4.3 + esbuild 0.17 (no macOS 11+ requirement).
export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    fs: { allow: ["."] },
    proxy: {
      "/api": {
        target: "http://localhost:8787",
        changeOrigin: true,
        // keep the emergency stream open
        proxyTimeout: 0,
        timeout: 0,
        configure: (proxy) => {
          proxy.on("proxyReq", (proxyReq) => {
            proxyReq.setHeader("X-Accel-Buffering", "no");
          });
        },
      },
    },
  },
  build: {
    outDir: "dist",
    target: "es2018",
    sourcemap: false,
  },
});
